def main():
    print("Project initialized")

print("All imports successful")

if __name__ == "__main__":
    main()
    